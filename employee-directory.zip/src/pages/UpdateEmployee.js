import React, {useEffect, useState} from 'react';
import EmployeeForm from '../components/EmployeeForm';
import axios from "axios";
import {useParams} from "react-router-dom";

function UpdateEmployee({ employees }) {
    const { id } = useParams();
    const [employee, setEmployee] = useState('');
    useEffect(() => {
        const getEmployee = async () => {
            const response = await axios.get(`${process.env.REACT_APP_API_URL}/api/employee/${id}`);
            setEmployee(response.data.data);
        };

        getEmployee();
    }, []);

    return (
        <div className="isolate bg-white px-6 py-8 lg:px-8">
            <div
                className="absolute inset-x-0 top-[-10rem] -z-10 transform-gpu overflow-hidden blur-3xl sm:top-[-20rem]"
                aria-hidden="true">
                <div
                    className="relative left-1/2 -z-10 aspect-[1155/678] w-[36.125rem] max-w-none -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-[#ff80b5] to-[#9089fc] opacity-30 sm:left-[calc(50%-40rem)] sm:w-[72.1875rem]"></div>
            </div>
            <div className="mx-auto max-w-2xl text-center">
                <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Update employee</h2>
            </div>
            <EmployeeForm employee={employee}></EmployeeForm>
        </div>
    );
}

export default UpdateEmployee;
