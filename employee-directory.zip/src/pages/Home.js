// Home.js
import React, { useEffect, useState } from 'react';
import { fetchEmployees } from '../services/employeeService';
import EmployeeList from '../components/EmployeeList';

function Home() {
    const [employees, setEmployees] = useState({});
    const [query, setQuery] = useState({
        query: '',
        page: ''
    });
    const [valueFromChild, setValueFromChild] = useState(null);

    useEffect(() => {
        const getEmployees = async (query_param) => {
            const data = await fetchEmployees(query_param);
            setEmployees(data);
        };
        const queryData = query?.query || '';
        const pageData = query?.page || '';
        let query_param = `?search=${queryData}&page=${pageData}`;
        getEmployees(query_param);

    }, [query]);

    // Callback function to receive values from the child
    const handleValueFromChild = (value) => {
        setQuery(value);
        setValueFromChild(value);
    };
    return (
        <div>
            <EmployeeList employees={employees} onValueChange={handleValueFromChild} />
        </div>
    );
}

export default Home;
