import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './pages/Home';
import AddEmployee from './pages/AddEmployee';
import UpdateEmployee from './pages/UpdateEmployee';
import Layout from "./components/layout/Layout";

import './App.css';

function App() {
  return (
      <Router>
        <Routes>
          <Route path="/"  element={
              <Layout>
                  <Home/>
              </Layout>
          } />
          <Route path="/add" element={
              <Layout>
                  <AddEmployee/>
              </Layout>
          } />
          <Route path="/update/:id" element={
              <Layout>
                  <UpdateEmployee/>
              </Layout>
              } />
        </Routes>
      </Router>
  );
}

export default App;
