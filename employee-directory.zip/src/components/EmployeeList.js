import React, {useEffect, useState} from 'react';
import { useNavigate, Link  } from 'react-router-dom';
import TableLoading from '../components/skeleton/table';
import axios from "axios";

function EmployeeList({ employees, onValueChange  }) {
    const navigate = useNavigate();
    const { data, page, pageSize, totalEmployees, totalPages } = employees;

    const [query, setQuery] = useState('');
    const [currentPage, setCurrentPage] = useState(page);


    const updatePaginateValue = async (value, type) => {
        if (type === 'page'){
            onValueChange({
                page: value,
                query: query.toLowerCase()
            })
            setCurrentPage(value)
        }
        if (type === 'query'){
            onValueChange({
                page: currentPage,
                query: value.toLowerCase()
            })
        }

    }
        const deleteEmployee = async (id, index) => {
            await axios.post(`${process.env.REACT_APP_API_URL}/api/employee/${id}/delete`);
            window.location.reload();
        }

    return (
            <div className="relative overflow-x-auto shadow-md container">
                <div
                    className="w-full p-5 flex text-lg font-semibold text-left rtl:text-right text-gray-900 bg-white dark:text-white dark:bg-gray-800">
                <div>
                <span>
                    Employee Directory
               </span>
            </div>
                    <a href="/add"
                        className="ml-auto inline-block text-sm px-4 py-2 leading-none border rounded text-teal-500 border-teal-500 hover:border-teal-500 hover:text-white hover:bg-teal-500 mt-4 lg:mt-0 cursor-pointer">Add employee</a>
                </div>
                {!data  ? (
                    <TableLoading count={5}></TableLoading>
                ) :
                    <div className="relative overflow-x-auto shadow-md">
                        <div
                            className="flex items-center justify-between flex-column flex-wrap md:flex-row space-y-4 md:space-y-0 p-4 bg-white dark:bg-gray-900">
                            <label htmlFor="table-search" className="sr-only">Search</label>
                            <div className="relative">
                                <input type="text" id="table-search-users"
                                       onChange={(e) => {
                                           console.log('Input value changed:', e.target.value);
                                           updatePaginateValue(e.target.value, 'query');
                                       }}
                                       className="block p-2 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg w-80 bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                       placeholder="Search for users"/>
                            </div>
                        </div>
                        <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                            <thead
                                className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                            <tr>
                                <th scope="col" className="p-4">
                                    <div className="flex items-center">
                                        <input id="checkbox-all-search" type="checkbox"
                                               className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 dark:focus:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"/>
                                            <label htmlFor="checkbox-all-search" className="sr-only">checkbox</label>
                                    </div>
                                </th>
                                <th scope="col" className="px-6 py-3">
                                    Name
                                </th>
                                <th scope="col" className="px-6 py-3">
                                    Phone
                                </th>
                                <th scope="col" className="px-6 py-3">
                                    Department
                                </th>
                                <th scope="col" className="px-6 py-3">
                                    Job Title
                                </th>
                                <th scope="col" className="px-6 py-3">
                                    Address
                                </th>
                                <th scope="col" className="px-6 py-3">

                                </th>
                            </tr>
                            </thead>
                            <tbody>
                            {data?.map((employee, key) => (
                            <tr key={key} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                                <td className="w-4 p-4">
                                    <div className="flex items-center">
                                        <input id="checkbox-table-search-1" type="checkbox"
                                               className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 dark:focus:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600" />
                                            <label htmlFor="checkbox-table-search-1" className="sr-only">checkbox</label>
                                    </div>
                                </td>
                                <th scope="row"
                                    className="flex items-center px-6 py-4 text-gray-900 whitespace-nowrap dark:text-white">
                                    <img className="w-10 h-10 rounded-full"
                                         src={`${process.env.REACT_APP_API_URL}${employee.media}`} alt={employee.firstName} />
                                        <div className="ps-3">
                                            <div className="text-base font-semibold">{employee.firstName} {employee.lastName}</div>
                                            <div className="font-normal text-gray-500">{employee.email}</div>
                                        </div>
                                </th>
                                <td className="px-6 py-4">
                                    {employee.phone}
                                </td>
                                <td className="px-6 py-4">
                                    {employee.department}
                                </td>
                                <td className="px-6 py-4">
                                    {employee.jobTitle}
                                </td>
                                <td className="px-6 py-4">
                                    {employee.address}
                                </td>
                                <td className="px-6 py-4">
                                    <Link to={`/update/${employee._id}`}
                                       className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 border border-blue-700 rounded">
                                        Edit</Link>
                                    <button onClick={() => deleteEmployee(employee._id)}
                                        className="bg-white hover:bg-gray-100 text-gray-800 font-semibold py-2 px-4 border border-gray-400 rounded ml-1 ">
                                        Delete
                                    </button>
                                </td>
                            </tr>
                            ))}
                            </tbody>
                        </table>
                        <nav aria-label="Page navigation example" className="flex justify-between items-center p-4">
                            <p className="text-sm">Showing {(page - 1) * pageSize + 1} to {Math.min(page * pageSize, totalEmployees)} of {totalEmployees} entries</p>
                            <ul className="inline-flex -space-x-px text-sm">
                                <li onClick={() => updatePaginateValue(parseInt(page) - 1 , 'page')} className="cursor-pointer flex items-center justify-center px-3 h-8 ms-0 leading-tight text-gray-500 bg-white border border-e-0 border-gray-300 rounded-s-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">
                                    <Link to={`/?page=${page - 1}`} className={`pagination-link ${page === 1 ? 'disabled' : ''}`}>
                                        Previous
                                    </Link>
                                </li>
                                {[...Array(totalPages).keys()].map((pageNumber) => (
                                    <li key={pageNumber} onClick={() => updatePaginateValue(parseInt(pageNumber) + 1 , 'page')} className="cursor-pointer flex items-center justify-center px-3 h-8 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">
                                        <Link to={`/?page=${pageNumber + 1}`} className={`pagination-link ${pageNumber + 1 === page ? 'active' : ''}`}>
                                            {pageNumber + 1}
                                        </Link>
                                    </li>
                                ))}
                                <li onClick={() => updatePaginateValue(parseInt(page) + 1, 'page')} className="cursor-pointer flex items-center justify-center px-3 h-8 leading-tight text-gray-500 bg-white border border-gray-300 rounded-e-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">
                                    <Link to={`/?page=${page + 1}`}  className={`pagination-link ${page === totalPages ? 'disabled' : ''}`}>
                                        Next
                                    </Link>
                                </li>
                            </ul>
                        </nav>
                    </div>
                }
            </div>
    );
}
export default EmployeeList;
