import React, {useEffect, useState} from 'react';
import axios from 'axios';
import { useNavigate  } from 'react-router-dom';

function EmployeeForm({ employee }) {
    console.log('employee', employee);
    const navigate = useNavigate(); // Use useNavigate instead of useHistory
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [department, setDepartment] = useState('');
    const [address, setAddress] = useState('');
    const [jobTitle, setJobTitle] = useState('');
    const [image, setImage] = useState(null);
    const [imagePreview, setImagePreview] = useState(null); // Added state for image preview
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const [info, setInfo] = useState('');

    const setUserDetail = (employee) => {
        setFirstName(employee.firstName);
        setLastName(employee.lastName);
        setEmail(employee.email);
        setPhone(employee.phone);
        setDepartment(employee.department);
        setAddress(employee.address);
        setJobTitle(employee.jobTitle);
        setImage(employee.media);
        setImagePreview(process.env.REACT_APP_API_URL+employee.media);
    }
    useEffect(() => {
        if (employee && Object.keys(employee).length > 0) {
            setUserDetail(employee);
            setInfo(`/${employee._id}/update`);
        }
    }, [employee]); // Dependency array includes employee

    const saveEmployee = async (e) => {
        setLoading(true);
        e.preventDefault();

        // Basic form validation
        if (!firstName || !lastName || !department || !email || !phone || !image) {
            setError('All fields are required.');
            setLoading(false);
            return;
        }

        const formData = new FormData();
        formData.append('firstName',firstName);
        formData.append('lastName',lastName);
        formData.append('email',email);
        formData.append('phone',phone);
        formData.append('image',image);
        formData.append('department',department);
        formData.append('address',address);
        formData.append('jobTitle',jobTitle);
        try {

            await axios.post(`${process.env.REACT_APP_API_URL}/api/employee${info}`, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });
            navigate('/');
            // Clear the form and error message after successful creation
        } catch (error) {
            console.error('Error creating employee:', error);
        }finally {
            setLoading(false); // Set loading to false whether the request succeeds or fails
        }
    };
    const handleImageChange = (e) => {
        const selectedImage = e.target.files[0];

        // Display image preview
        const reader = new FileReader();
        reader.onloadend = () => {
            setImage(selectedImage);
            setImagePreview(reader.result);
        };
        reader.readAsDataURL(selectedImage);
    };


    return (
            <form onSubmit={saveEmployee} className="mx-auto mt-8 max-w-xl sm:mt-8">
                <div className="grid grid-cols-1 gap-x-8 gap-y-6 sm:grid-cols-2">
                    <div className="">
                        <label htmlFor="phone-number" className="block text-sm font-semibold leading-6 text-gray-900">
                            User Profile
                        </label>
                        <div className="relative mt-2.5 flex">
                            <input id="upload_user_image" accept="image/*" onChange={handleImageChange} type="file" name="image" />
                        </div>
                    </div>
                    <div >
                        {imagePreview && <img src={imagePreview} alt="Preview" className="rounded-full w-32 h-32 border-2 border-gray-300"  style={{ maxWidth: '100px', maxHeight: '100px' }} />}
                    </div>
                    <div>
                        <label htmlFor="first-name" className="block text-sm font-semibold leading-6 text-gray-900">First
                            name
                        </label>
                        <div className="mt-2.5">
                            <input type="text" name="first-name" value={firstName} onChange={(e) => setFirstName(e.target.value)} id="first-name" autoComplete="given-name" placeholder="First name"
                                   required className="block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6" />
                        </div>
                    </div>
                    <div>
                        <label htmlFor="last-name" className="block text-sm font-semibold leading-6 text-gray-900">Last
                            name</label>
                        <div className="mt-2.5">
                            <input type="text" name="last-name" value={lastName} onChange={(e) => setLastName(e.target.value)} id="last-name" autoComplete="family-name" placeholder="Last name"
                                   required className="block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6" />
                        </div>
                    </div>
                    <div className="sm:col-span-2">
                        <label htmlFor="email"
                               className="block text-sm font-semibold leading-6 text-gray-900">Email</label>
                        <div className="mt-2.5">
                            <input type="email" name="email" value={email} onChange={(e) => setEmail(e.target.value)} id="email" autoComplete="email" placeholder="Email address"
                                   required className="block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"/>
                        </div>
                    </div>
                    <div className="sm:col-span-2">
                        <label htmlFor="jobTitle" className="block text-sm font-semibold leading-6 text-gray-900">
                            Job Title
                        </label>
                        <div className="relative mt-2.5">
                            <input type="test" name="jobTitle" value={jobTitle} onChange={(e) => setJobTitle(e.target.value)} id="address" autoComplete="jobTitle" placeholder="Job title"
                                   required className="block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6" />
                        </div>
                    </div>
                    <div>
                        <label htmlFor="department"
                               className="block text-sm font-semibold leading-6 text-gray-900">Company</label>
                        <div className="mt-2.5">
                            <input type="text" name="department" value={department} onChange={(e) => setDepartment(e.target.value)} id="department" autoComplete="organization" placeholder="Department"
                                   required className="block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"/>
                        </div>
                    </div>
                    <div>
                        <label htmlFor="phone-number" className="block text-sm font-semibold leading-6 text-gray-900">Phone
                            number</label>
                        <div className="relative mt-2.5">
                            <input type="tel" name="phone-number" value={phone} onChange={(e) => setPhone(e.target.value)} id="phone-number" autoComplete="tel" placeholder="Phone number"
                                   required className="block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6" />
                        </div>
                    </div>

                    <div className="sm:col-span-2">
                        <label htmlFor="address" className="block text-sm font-semibold leading-6 text-gray-900">
                            Address
                        </label>
                        <div className="relative mt-2.5">
                            <input type="test" name="address" value={address} onChange={(e) => setAddress(e.target.value)} id="address" autoComplete="address" placeholder="Address"
                                   required className="block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6" />
                        </div>
                    </div>
                </div>
                <div className="mt-10">
                    {error && <p style={{ color: 'red' }}>{error}</p>}
                    <button type="submit"
                            className="block w-full rounded-md bg-indigo-600 px-3.5 py-2.5 text-center text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
                        {loading ?
                            <img className="m-auto w-5" src="https://cdn.pixabay.com/animation/2023/05/02/04/29/04-29-06-428_512.gif" alt="loading..."/> : 'Create'
                        }
                    </button>
                </div>
            </form>
    );
}

export default EmployeeForm;
