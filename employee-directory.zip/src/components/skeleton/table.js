import React, {useEffect, useState} from 'react';
import { useNavigate, Link  } from 'react-router-dom';
import axios from "axios";

function TableLoading({ count }) {
    const items = Array.from({ length: count }, (value, index) => index);
    return (
        <div>
            {items.map((key) => (
            <div key={key} className="border border-blue-300 shadow p-4 w-full mx-auto">
                <div className="animate-pulse flex space-x-4">
                    <div className="rounded-full bg-slate-700 h-10 w-10"></div>
                    <div className="flex-1 space-y-6 py-1">
                        <div className="h-2 bg-slate-700 rounded"></div>
                        <div className="space-y-3">
                            <div className="grid grid-cols-6 gap-4">
                                <div className="h-2 bg-slate-700 rounded col-span-1"></div>
                                <div className="h-2 bg-slate-700 rounded col-span-1"></div>
                                <div className="h-2 bg-slate-700 rounded col-span-1"></div>
                                <div className="h-2 bg-slate-700 rounded col-span-1"></div>
                                <div className="h-2 bg-slate-700 rounded col-span-1"></div>
                                <div className="h-2 bg-slate-700 rounded col-span-1"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                ))}
        </div>
    );
}

export default TableLoading;
