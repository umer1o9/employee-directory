const employeeModel = require('../models/Employee');
const employeeService = require('../services/employeeService');


exports.getAllEmployee = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const pageSize = parseInt(req.query.pageSize) || 10;
        const searchQuery = req.query.search || ''; // Get the search query from the request parameters

        const skip = (page - 1) * pageSize;

        const query = { $or: [
                { firstName: { $regex: new RegExp(searchQuery, 'i') } },
                { lastName: { $regex: new RegExp(searchQuery, 'i') } },
                { phone: { $regex: new RegExp(searchQuery, 'i') } },
                { jobTitle: { $regex: new RegExp(searchQuery, 'i') } },
                { position: { $regex: new RegExp(searchQuery, 'i') } },
                { department: { $regex: new RegExp(searchQuery, 'i') } },
                { email: { $regex: new RegExp(searchQuery, 'i') } },
            ],}; // Using $text for text search; adjust based on your model

        const employees = await employeeModel
            .find(query)
            .sort({ "_id": -1 })
            .skip(skip)
            .limit(pageSize);

        const totalEmployees = await employeeModel.countDocuments(query);
        const totalPages = Math.ceil(totalEmployees / pageSize);

        res.json({
            data: employees,
            page,
            pageSize,
            totalEmployees,
            totalPages: totalPages,
            hasPreviousPage: page > 1,
            hasNextPage: page < totalPages,
            isFirstPage: page === 1,
            isLastPage: page === totalPages,
            status: "success",
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

exports.createEmployee = async (req, res) => {
    try {
        // console.log("req.file.path", req.file);
        // console.log("req.params", req.params);
        // console.log("req.body", req.body);
        // console.log("req.query", req.query);

        const { firstName, lastName, email, phone, department, address, jobTitle } = req.body;
        const employee = await employeeService.createEmployee({
            firstName,
            lastName,
            email,
            phone,
            department,
            address,
            jobTitle,
            media: req.file ? `/uploads/${req.file.filename}`  : undefined,
        });
        res.json({
            status: "success",
            data: employee
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

exports.getSingle = async (req, res) => {
    try {
        let id = req.params.id;

        const employee = await employeeService.getEmployeeById(id);

        res.status(200).json({
            status: true,
            message: "Employee found",
            data: employee,
        });
    }catch (err){
        res.status(500).json({ error: err.message });
    }
}

exports.update = async (req, res) => {
    try {
        let id = req.params.id;
        const params = req.body || {};
        const { firstName, lastName, email, phone, department, address, jobTitle } = req.body;
        const employeeDetail = {
            firstName,
            lastName,
            email,
            phone,
            department,
            address,
            jobTitle,
        };

        if (req.file){
            employeeDetail['media'] = `/uploads/${req.file.filename}`;
        }

        const employee = await employeeService.updateEmployee(id, employeeDetail);
        if (employee != null){
            res.status(200).json({
                status: true,
                message: "employee detail updated successfully",
                data: employee,
            });
        }else{
            res.status(404).json({
                status: true,
                message: "Employee not found",
                data: {},
            });
        }

    }catch (err){
        res.status(500).json({ error: err.message });
    }
}
exports.delete = async (req, res) => {
    try {
        let id = req.params.id;
        await employeeService.deleteEmployee(id);
        res.status(200).json({
            status: true,
            message: "employee removed successfully",
            data: {},
        });
    }catch (err){
        res.status(500).json({ error: err.message });
    }
}
