const mongoose = require("mongoose");
const {text} = require("express");
const Schema = mongoose.Schema;

const employeeSchema = new Schema({
    firstName: String,
    lastName: String,
    email: {
        type: String,
        required: true,
        unique: true
    },
    department: String,
    phone: String,
    location: String,
    media: String,
    jobTitle: String,
    address: String,
    createdAt: {
        type: Date,
        default: Date.now(),
    },
})

module.exports = mongoose.model("Employee", employeeSchema);
