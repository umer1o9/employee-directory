const employeeModel = require("../models/Employee");

exports.getAllEmployee = async () => {
    return employeeModel.find();
};

exports.createEmployee = async (employee) => {
    return await employeeModel.create(employee);
};
exports.getEmployeeById = async (id) => {
    return employeeModel.findById(id);
};

exports.updateEmployee = async (id, employee) => {
    return employeeModel.findByIdAndUpdate(id, employee);
};

exports.deleteEmployee = async (id) => {
    return employeeModel.findByIdAndDelete(id);
};
