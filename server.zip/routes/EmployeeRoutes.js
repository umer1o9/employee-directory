const express = require("express");
const router = express.Router();
const employeeController = require('../controllers/employeeController');



router.route("/").get(employeeController.getAllEmployee);
router.route("/").post(employeeController.createEmployee);
router.route("/:id").get(employeeController.getSingle);
router.route("/:id/update").post(employeeController.update);
router.route("/:id/delete").post(employeeController.delete);
module.exports = router;
