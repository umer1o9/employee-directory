const express = require("express");
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require("cors");
const multer = require('multer');
const path = require('path');

require("dotenv").config();
const employeeRouter = require("./routes/EmployeeRoutes");

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use('/uploads', express.static('uploads'));

const port = process.env.PORT || 3001;
const uri = "mongodb+srv://umerrasheed3:XYc4KxYbZGhM7B49@cluster0.mr2hfyt.mongodb.net/?retryWrites=true&w=majority";
// Connect to MongoDB
async function connect() {
  try {
    await mongoose.connect(uri);
    console.log("connected to MongoDB");
  } catch (error) {
    console.error(error);
  }
}
connect();
app.use(cors())
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));
// parse application/json
app.use(bodyParser.json());

const storage = multer.diskStorage({
  destination: 'uploads/',
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({ storage: storage });
const employeeModel = require("./models/Employee");
const employeeService = require("./services/employeeService");

app.use("/api/employee", upload.single('image'), employeeRouter);

app.listen(port, () => {
  console.log(`Example app listening on port ${port}!`);
});
